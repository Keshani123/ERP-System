
<?php
// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Retrieve form data
  $title = $_POST['title'];
  $firstName = $_POST['firstName'];
  $lastName = $_POST['lastName'];
  $contactNumber = $_POST['contactNumber'];
  $district = $_POST['district'];

  // TODO: Perform form validation here (e.g., checking if data is valid, sanitizing inputs, etc.)

  // TODO: Save the data into the database (MySQL) using appropriate SQL queries

  // Redirect back to the customer form after successful registration
  header('Location: customer_form.php');
  exit;
}

// create the connection with db
$connection = mysqli_connect('localhost','root','','sms');

//	the query to execute
$query = "INSERT INTO customer (title,firstName,lastName,contactNumber,district) VALUES
('$title','$firstName','$lastName','$contactNumber','$district')";



?>


      




<html>
   <head>
      <title></title>
          <!-- Include Bootstrap CSS link -->
          <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>


<body>
  <div class="container mt-4">
     <h2>Customer Registration Form</h2>
      <form id="customerForm" action="process_customer.php" method="post">
        <div class="mb-3">
         <label for="title" class="form-label">Title</label>
         <select class="form-select" id="title" name="title" required>
            <option value=""></option>
            <option value="Mr">Mr</option>
            <option value="Mrs">Mrs</option>
            <option value="Miss">Miss</option>
            <option value="Dr">Dr</option>
         </select>
    </div>
    <div class="mb-3">
      <label for="firstName" class="form-label">First Name</label>
      <input type="text" class="form-control" id="firstName" name="firstName" required>
    </div>
    <div class="mb-3">
      <label for="lastName" class="form-label">Last Name</label>
      <input type="text" class="form-control" id="lastName" name="lastName" required>
    </div>
    <div class="mb-3">
      <label for="contactNumber" class="form-label">Contact Number</label>
      <input type="tel" class="form-control" id="contactNumber" name="contactNumber" required >
    </div>
    <div class="mb-3">
      <label for="district" class="form-label">District</label>
      <input type="text" class="form-control" id="district" name="district" required>
    </div>
    <button type="submit" class="btn btn-primary"  onclick="">Next</button>
    
    

  </form>
</div>
</body>
<html>