<?php
// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Retrieve form data
  $itemCode = $_POST['itemCode'];
  $itemName = $_POST['itemName'];
  $itemCategory = $_POST['itemCategory'];
  $itemSubCategory = $_POST['itemSubCategory'];
  $quantity = $_POST['quantity'];
  $unitPrice = $_POST['unitPrice'];

  // TODO: Perform form validation here (e.g., checking if data is valid, sanitizing inputs, etc.)

  // TODO: Save the data into the database (MySQL) using appropriate SQL queries

  // Redirect back to the customer form after successful registration
  header('Location: customer_form.php');
  exit;
}
?>

<html>
    <head>
       <title>Registration Form</title>
    
       <!-- Include Bootstrap CSS link -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
   </head>

<body>
  <div class="container mt-4">
    <h2>Item Registration Form</h2>
     <form id="itemForm" action="process_item.php" method="post">
    <div class="mb-3">
      <label for="itemCode" class="form-label">Item Code</label>
      <input type="text" class="form-control" id="itemCode" name="itemCode" required>
    </div>
    <div class="mb-3">
      <label for="itemName" class="form-label">Item Name</label>
      <input type="text" class="form-control" id="itemName" name="itemName" required>
    </div>
    <div class="mb-3">
      <label for="itemCategory" class="form-label">Item Category</label>
      <select class="form-select" id="itemCategory" name="itemCategory" required>
        <option value=""></option>
        <option value="category1">Printers</option>
        <option value="category2">Laptops</option>
        <option value="category2">Gadgets</option>
        <option value="category2">Ink bottels</option>
        <option value="category2">Cartridges</option>
        <!-- Add options for item categories -->
      </select>
    </div>
    <div class="mb-3">
      <label for="itemSubCategory" class="form-label">Item Sub Category</label>
      <select class="form-select" id="itemSubCategory" name="itemSubCategory" required>
        <option value=""></option>
        <option value="category1">HP</option>
        <option value="category2">Dell</option>
        <option value="category2">Lenovo</option>
        <option value="category2">Acer</option>
        <option value="category2">Samsung</option>
        
        <!-- Add options for item subcategories -->
      </select>
    </div>
    <div class="mb-3">
      <label for="quantity" class="form-label">Quantity</label>
      <input type="number" class="form-control" id="quantity" name="quantity" required>
    </div>
    <div class="mb-3">
      <label for="unitPrice" class="form-label">Unit Price</label>
      <input type="number" class="form-control" id="unitPrice" name="unitPrice" step="0.01" required>
    </div>
    <button type="submit" class="btn btn-primary">Save</button >
    <a href=
  </form>
</div>
</body>
</html>

